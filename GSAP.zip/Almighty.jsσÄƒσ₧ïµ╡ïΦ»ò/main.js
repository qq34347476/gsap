var win = nw.Window.get();
document.getElementById('close').addEventListener('click',function(){
	win.close()
})
console.log(win);